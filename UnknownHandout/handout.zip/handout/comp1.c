#include "comp1.h"

void problem1(long long *intArray, int tests[][4]){
	
}